package com.example.application;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class HomeFragment extends Fragment implements View.OnClickListener {

    Context context;
    Placement placement;
    TextView textPredict;
    EditText editTextEQScore, editTextIQScore, editTextTechnicalSkills, editTextSoftSkills,
            editTextExtracurricularActivities, editTextHackathons, editTextProjects,
            editTextCgpa, editTextInternships;
    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getActivity().setTitle("NextGenRecruit");

        placement = new Placement();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        this.context = container.getContext();

        editTextEQScore = view.findViewById(R.id.editTextEQScore);
        editTextIQScore = view.findViewById(R.id.editTextIQScore);
        editTextTechnicalSkills = view.findViewById(R.id.editTextTechnicalSkills);
        editTextSoftSkills = view.findViewById(R.id.editTextSoftSkills);
        editTextExtracurricularActivities = view.findViewById(R.id.editTextExtracurricularActivities);
        editTextHackathons = view.findViewById(R.id.editTextHackathons);
        editTextProjects = view.findViewById(R.id.editTextProjects);
        editTextCgpa = view.findViewById(R.id.editTextCgpa);
        editTextInternships = view.findViewById(R.id.editTextInternships);
        textPredict=view.findViewById(R.id.textPredict);
        Button btnPredictPlacement = view.findViewById(R.id.btnPredictPlacement);
        btnPredictPlacement.setOnClickListener(this);
        return view;
    }

    private void getPredictPlacement() {

        String url = "http://35.168.105.129/predictPlacement?";
        url += "EQScore=" + placement.EQScore + "&";
        url += "IQScore=" + placement.IQScore + "&";
        url += "TechnicalSkills=" + placement.TechnicalSkills + "&";
        url += "SoftSkills=" + placement.SoftSkills + "&";
        url += "ExtracurricularActivities=" + placement.ExtracurricularActivities + "&";
        url += "Hackathons=" + placement.Hackathons + "&";
        url += "Projects=" + placement.Projects + "&";
        url += "Cgpa=" + placement.Cgpa + "&";
        url += "Internships=" + placement.Internships;

        // creating a new variable for our request queue
        RequestQueue queue = Volley.newRequestQueue(context);

        // make json array request and then extracting data from each json object.
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject responseObj = response.getJSONObject(0);

                    String returnValue = responseObj.getString("Placement");
                    textPredict.setText("Placement: " + returnValue);

                    Toast.makeText(context, returnValue, Toast.LENGTH_SHORT).show();
                    if (returnValue.equals("1")) {
                        textPredict.setText("Hurray..!Can Be Placed..!");
                    } else {
                        textPredict.setText("Can't Be Placed, Need to improve skills you are lacking in..!");
                    }

                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Fail to get the data..", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(jsonArrayRequest);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnPredictPlacement:
                placement.EQScore = editTextEQScore.getText().toString();
                placement.IQScore = editTextIQScore.getText().toString();
                placement.TechnicalSkills = editTextTechnicalSkills.getText().toString();
                placement.SoftSkills = editTextSoftSkills.getText().toString();
                placement.ExtracurricularActivities = editTextExtracurricularActivities.getText().toString();
                placement.Hackathons = editTextHackathons.getText().toString();
                placement.Projects = editTextProjects.getText().toString();
                placement.Cgpa = editTextCgpa.getText().toString();
                placement.Internships = editTextInternships.getText().toString();

                getPredictPlacement();
                textPredict.setText("wait..");
                break;
        }
    }
}