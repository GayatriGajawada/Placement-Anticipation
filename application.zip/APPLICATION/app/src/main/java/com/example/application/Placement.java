package com.example.application;

public class Placement {

    public String EQScore;
    public String IQScore;
    public String TechnicalSkills;
    public String SoftSkills;
    public String ExtracurricularActivities;
    public String Hackathons;
    public String Projects;
    public String Cgpa;
    public String Internships;



}
